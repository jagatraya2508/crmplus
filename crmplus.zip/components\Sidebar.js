'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
    LayoutDashboard, Users, GitBranch, ShoppingCart, MapPin,
    Megaphone, UserPlus, BarChart3, Settings, ChevronLeft,
    ChevronRight, Zap, Package, UserCog, Radio, Activity
} from 'lucide-react';
import { useAuth } from '@/components/AppShell';
import './Sidebar.css';

const menuItems = [
    { href: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { href: '/leads', icon: UserPlus, label: 'Leads' },
    { href: '/customers', icon: Users, label: 'Pelanggan' },
    { href: '/activities', icon: Activity, label: 'Activity Log' },
    { href: '/pipeline', icon: GitBranch, label: 'Pipeline' },
    { href: '/visits', icon: MapPin, label: 'Kunjungan' },
    { href: '/orders', icon: ShoppingCart, label: 'Pesanan' },
    { href: '/products', icon: Package, label: 'Produk' },
    { href: '/product-categories', icon: Package, label: 'Kategori Produk' },
    { href: '/tracking', icon: Radio, label: 'Live Tracking', adminOnly: true },
    { href: '/campaigns', icon: Megaphone, label: 'Kampanye' },
    { href: '/reports', icon: BarChart3, label: 'Laporan' },
    { href: '/users', icon: UserCog, label: 'Kelola User', adminOnly: true },
    { href: '/settings', icon: Settings, label: 'Pengaturan' },
];

export default function Sidebar({ collapsed, onToggle }) {
    const pathname = usePathname();
    const { user, settings } = useAuth();

    const visibleItems = menuItems.filter(item => !item.adminOnly || user?.role === 'admin');

    return (
        <aside className={`sidebar ${collapsed ? 'collapsed' : ''}`}>
            <div className="sidebar-header">
                <div className={`sidebar-logo ${!settings?.app_logo ? 'fallback-logo' : ''}`}>
                    {settings?.app_logo ? (
                        <img
                            src={settings.app_logo}
                            alt="App Logo"
                            style={{
                                height: 32,
                                width: collapsed ? 32 : 'auto',
                                maxWidth: 180,
                                objectFit: 'contain',
                                transition: 'all 0.3s ease'
                            }}
                        />
                    ) : (
                        <>
                            <div className="logo-icon">
                                <Zap size={24} />
                            </div>
                            {!collapsed && <span className="logo-text">CRM<span className="logo-plus">Plus</span></span>}
                        </>
                    )}
                </div>
                <button className="sidebar-toggle" onClick={onToggle} aria-label="Toggle sidebar">
                    {collapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
                </button>
            </div>

            <nav className="sidebar-nav">
                {visibleItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = pathname === item.href || pathname?.startsWith(item.href + '/');
                    return (
                        <Link
                            key={item.href}
                            href={item.href}
                            className={`nav-item ${isActive ? 'active' : ''}`}
                            title={collapsed ? item.label : undefined}
                        >
                            <Icon size={20} />
                            {!collapsed && <span className="nav-label">{item.label}</span>}
                            {isActive && <div className="nav-indicator" />}
                        </Link>
                    );
                })}
            </nav>

            <div className="sidebar-footer">
                {!collapsed && (
                    <div className="sidebar-version">
                        <span>CRM Plus v1.0</span>
                    </div>
                )}
            </div>
        </aside>
    );
}
